StudentNumber|13659990
FullName|Se Hyeon Jung
Login examples
sehyeon|12354
booker|123765
