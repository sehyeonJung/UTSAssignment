﻿using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Dynamic;

namespace assignment1
{
   

    class BankManegement
    {
        protected static int origRow;
        protected static int origCol;
        private static List<bankAccount> Accounts = new List<bankAccount>();

        public static void GetBA()
        {
            
            for (int i = 100000; i < 1000000; i++)
            {
                if (File.Exists($"{i}.txt"))
                {
                    StreamReader st = new StreamReader($"{i}.txt");
                    String FNline = st.ReadLine();
                    String FN = FNline.Substring(10);
                    String LNline = st.ReadLine();
                    String LN = LNline.Substring(9);
                    String ADline = st.ReadLine();
                    String AD = ADline.Substring(8);
                    String PHline = st.ReadLine();
                    String PH = PHline.Substring(6);
                    String EMline = st.ReadLine();
                    String EM = EMline.Substring(6);
                    String ACline = st.ReadLine();
                    String AC = ACline.Substring(10);
                    String BLline = st.ReadLine();
                    String BL = BLline.Substring(8);
                    bankAccount bk = new bankAccount(Convert.ToInt32(AC), Convert.ToDouble(BL), FN, LN, AD, PH, EM);
                    Accounts.Add(bk);

                }
            }
        }


        public BankManegement(int accountNum)
        {
            Accounts = new List<bankAccount>();
           
        }
        private bankAccount Account(int accountNumber)
        {
            foreach (bankAccount account in Accounts)
            {
                if (account.HasNumber(accountNumber))
                    return account;
            }
            return null;
        }
        static void Main(string[] args)
        {
            GetBA();
            bankAccount ex1 = new bankAccount(100001, 1000, "Sam", "Verge", "UTS Building 11, Sydney", "123456789", "samv@uts.edu.au");
            Accounts.Add(ex1); //System.NullReferenceException: 'Object reference not set to an instance of an object.'
            Login();    
        }
        protected static void WriteAt(string s, int x, int y)
        {
            try
            {
                Console.SetCursorPosition(origCol + x, origRow + y);
                Console.Write(s);
            }
            catch (ArgumentOutOfRangeException e)
            {
                Console.Clear();
                Console.WriteLine(e.Message);
            }
        }

        public static void Login()
        {
            
            Console.Clear();
            origRow = Console.CursorTop;
            origCol = Console.CursorLeft;

            WriteAt("=======================================", 1, 0);
            WriteAt("|", 0, 1);
            WriteAt("WELCOME RO SIMPLE BANKING SYSTEM", 4, 1);
            WriteAt("|", 0, 2);
            WriteAt("=======================================", 1, 2);
            WriteAt("|", 0, 3);
            WriteAt("LOGIN TO START", 13, 3);
            WriteAt("|", 0, 4);
            WriteAt("User Name:", 4, 4);

            WriteAt("|", 0, 5);
            WriteAt("Password:", 4, 5);
            WriteAt("|", 0, 6);

            WriteAt("|", 40, 1);
            WriteAt("|", 40, 2);
            WriteAt("|", 40, 3);
            WriteAt("|", 40, 4);
            WriteAt("|", 40, 5);
            WriteAt("|", 40, 6);
            WriteAt("=======================================", 1, 7);
            Console.SetCursorPosition(14, 4);
            String userIDinput = Console.ReadLine();
            WriteAt(userIDinput, 14, 4);
            Console.SetCursorPosition(14, 5);
            var userPWinput = string.Empty;//password show by *
            ConsoleKey key;
            do
            {
                var keyInfo = Console.ReadKey(intercept: true);
                key = keyInfo.Key;
                if (key == ConsoleKey.Backspace && userPWinput.Length > 0)
                {
                    Console.Write("\b \b");
                    userPWinput = userPWinput[0..^1];

                }
                else if (!char.IsControl(keyInfo.KeyChar))
                {
                    Console.Write("*");
                    userPWinput += keyInfo.KeyChar;

                }
            } while (key != ConsoleKey.Enter);

            Console.SetCursorPosition(0, 8);
            bool loginSuccessful = false;
            string[] loginCredentials = File.ReadAllLines("login.txt");
            foreach (string loginCredential in loginCredentials)
            {
                string[] separator = { "|", " " };
                string[] login = loginCredential.Split(separator, StringSplitOptions.RemoveEmptyEntries);
                if (userIDinput == login[0] && userPWinput == login[1])
                {
                    loginSuccessful = true;
                    MainPage();
                    break;
                }
                
            }
            if (!loginSuccessful)
            {
                Console.WriteLine(" Incorrect username or password.");
                Console.Write(" Retry (Y/N)? ");
                String choice = Console.ReadLine();

                if (choice == "y")
                {
                    Login();
                }
                else if (choice == "n")
                {
                    Console.ReadKey();
                }
            }


        }
        public static void MainPage()
        {
            Console.Clear();
            origRow = Console.CursorTop;
            origCol = Console.CursorLeft;
            WriteAt("=======================================", 1, 0);
            WriteAt("|", 0, 1);
            WriteAt("WELCOME TO SIMPLE BANKING JOB", 4, 1);
            WriteAt("|", 0, 2);
            WriteAt("=======================================", 1, 2);
            WriteAt("|", 0, 3);
            WriteAt("1. Create a new account", 3, 3);
            WriteAt("|", 0, 4);
            WriteAt("2. Search for an account", 3, 4);
            WriteAt("|", 0, 5);
            WriteAt("3. Deposit", 3, 5);
            WriteAt("|", 0, 6);
            WriteAt("4. Withdraw", 3, 6);
            WriteAt("|", 0, 7);
            WriteAt("5. A/C statement", 3, 7);
            WriteAt("|", 0, 8);
            WriteAt("6. Delete Account", 3, 8);
            WriteAt("|", 0, 9);
            WriteAt("7. Exit", 3, 9);
            WriteAt("|", 0, 10);
            WriteAt("|", 0, 11);
            WriteAt("|", 0, 12);

            WriteAt("|", 40, 1);
            WriteAt("|", 40, 2);
            WriteAt("|", 40, 3);
            WriteAt("|", 40, 4);
            WriteAt("|", 40, 5);
            WriteAt("|", 40, 6);
            WriteAt("|", 40, 7);
            WriteAt("|", 40, 8);
            WriteAt("|", 40, 9);
            WriteAt("|", 40, 10);
            WriteAt("|", 40, 11);
            WriteAt("|", 40, 12);
            WriteAt("=======================================", 1, 13);
            WriteAt("|", 0, 14);
            WriteAt("Enter your choice(1-7)", 4, 14);
            WriteAt("|", 40, 14);
            WriteAt("=======================================", 1, 15);
            
            String userChoice = Console.ReadLine();
            int userInput2 = Convert.ToInt32(userChoice);//??

            if (userInput2 == 1)
            {
                CreateNewAccount();
            }
            else if (userInput2 == 2)
            {
                SearchNewAccount();
            }
            else if (userInput2 == 3)
            {
                Deposit();
            }
            else if (userInput2 == 4)
            {
                Withdraw();
            }
            else if (userInput2 == 5)
            {
                ACStatement();  
            }
            else if (userInput2 == 6)
            {
                DeleteAccount();
            }
            else if (userInput2 == 7)
            {
                Console.Clear();
                Console.WriteLine("thanks for banking");
                Console.ReadKey();
            }
            else
            {
                Console.Clear();
                Console.WriteLine("please enter vaild options");
                Console.WriteLine("pleae press any key to continue");
                Console.Read();
                MainPage();
            }

        }

       

        private static void CreateNewAccount()
        {

            Console.Clear();
            origRow = Console.CursorTop;
            origCol = Console.CursorLeft;

            WriteAt("================================================================", 1, 0);
            WriteAt("|                      CREATE NEW ACCOUNT                      |", 0, 1);
            WriteAt("|==============================================================|", 0, 2);
            WriteAt("| First Name:                                                  |", 0, 3);
            WriteAt("| Last Name:                                                   |", 0, 4);
            WriteAt("| Address:                                                     |", 0, 5);
            WriteAt("| Phone Number:                                                |", 0, 6);
            WriteAt("| Email:                                                       |", 0, 7);
            WriteAt("| Password:                                                    |", 0, 8);
            WriteAt("================================================================", 1, 9);
            Console.SetCursorPosition(13, 3);
            String userFNInput = Console.ReadLine();
            Console.SetCursorPosition(12, 4);
            String userLNInput = Console.ReadLine();
            Console.SetCursorPosition(10, 5);
            String userADInput = Console.ReadLine();
            Console.SetCursorPosition(15, 6);
            String userPNInput = Console.ReadLine();
            Console.SetCursorPosition(8, 7);
            String userEMInput = Console.ReadLine();
            Console.SetCursorPosition(11, 8);
            String userPWInput = Console.ReadLine();

            Console.SetCursorPosition(1, 10);
            
            Console.WriteLine("Is the information correct? (y/n)");
            String userIn = Console.ReadLine();
            if (userIn == "y")
            {
                //add to the files
                Random random = new Random();
                int userAC = random.Next(100000, 999999);
                bankAccount newUser = new bankAccount(userAC, 0, userFNInput, userLNInput, userADInput, userPNInput, userEMInput);
                
                Console.WriteLine($"Your Account Number is {userAC}");

                Console.WriteLine("Account Created! details will be provided via email");

                
                SmtpClient client = new SmtpClient();
                client.Host = "smtp.gmail.com";
                client.Port = 587;
                
                client.EnableSsl = true;
                client.UseDefaultCredentials = true;
                client.Credentials = new NetworkCredential("sehyeon430@gmail.com", "soncyfdxtydfrzhd");
                
                MailMessage mail = new MailMessage(new MailAddress("sehyeon430@gmail.com", "simple bank system"), new MailAddress(userEMInput));

                mail.IsBodyHtml = true;
                mail.Subject = "Welcome to Simple Bank";
                mail.Body = string.Format($"Dear {userFNInput},<br><br>" +
                            "Welcome to Simple Bank Management System!<br><br>" +
                            "Your account details are as follow:<br>" +

                            $"Account number: {userAC}<br>" +
                            $"First name: {userFNInput}<br>" +
                            $"Last name: {userLNInput}<br>" +
                            $"Address: {userLNInput}<br>" +
                            $"Phone number: {userPNInput}<br>" +
                            $"Email: {userEMInput}<br><br>" +

                            "Kind regards,<br>" +
                            "The Simple Banking Team");
                client.Send(mail);
                

                File.AppendAllText("login.txt",$"{userFNInput}|{userPWInput}\r\n");
                StreamWriter streamWriter = new StreamWriter($"{userAC}.txt",true);
                streamWriter.WriteLine($"Firstname|{userFNInput}");
                streamWriter.WriteLine($"Lastname|{userLNInput}");
                streamWriter.WriteLine($"Address|{userADInput}");
                streamWriter.WriteLine($"Phone|{userFNInput}");
                streamWriter.WriteLine($"Email|{userEMInput}");
                streamWriter.WriteLine($"AccountNo|{userAC}");
                streamWriter.WriteLine("Balance|0\r\n");
                streamWriter.Close();
                Accounts.Add(newUser);

                Console.WriteLine("Do you wish to coninue another work? (y/n)");
                String userIn2 = Console.ReadLine();
                if (userIn2 == "y")
                {
                    MainPage();
                }
                else
                {
                    Console.WriteLine("Thanks");
                    Console.ReadKey();
                }

            }
            else if (userIn == "n") 
            {
                CreateNewAccount();
            }
            
        }
        public static void SearchNewAccount() 
        {
            Console.Clear();
            origRow = Console.CursorTop;
            origCol = Console.CursorLeft;
            WriteAt("=======================================", 1, 0);
            WriteAt("|         SEARCH AN ACCOUNT           |", 0, 1);
            WriteAt("|=====================================|", 0, 2);
            WriteAt("|          ENTER THE DETAIL           |", 0, 3);
            WriteAt("| Account number:                     |", 0, 4);
            WriteAt("=======================================", 1, 5);
            Console.SetCursorPosition(17, 4);
            String userACinput = Console.ReadLine();
            Console.SetCursorPosition(0, 6);

            if (File.Exists($"{userACinput}.txt"))
            {
                foreach (bankAccount bk in Accounts)
                {
                    if (bk.getNum() == Convert.ToInt32(userACinput))
                    {
                        bk.PrintAccountDetails();
                        Console.WriteLine("Press y to Search another account");
                        String Choice2 = Console.ReadLine();
                        if (Choice2 == "y")
                        {
                            SearchNewAccount();
                        }
                        else
                        {
                            Console.WriteLine("Wish to continue another work? (y/n)");
                            String Choice3 = Console.ReadLine();
                            if (Choice3 == "y")
                            {
                                MainPage();
                            }
                            else
                            {
                                Console.WriteLine("Thanks");
                                Console.ReadKey();
                            }
                        }
                    }
                }
            }
            else 
            {
                Console.WriteLine("Account not found!");
                Console.WriteLine("Check another account?(y/n)");
                String checkAnother = Console.ReadLine();
                if (checkAnother == "y")
                {
                    SearchNewAccount();
                }
                else 
                {
                    Console.WriteLine("Press y to continue another work");
                    String checkAnother2 = Console.ReadLine();
                    if (checkAnother2.Equals("y"))
                    {
                        MainPage();
                    }
                    else {
                        Console.WriteLine("Thanks");
                        Console.ReadKey();
                    }
                }
            }
        }
        public static void Deposit()
        {
            Console.Clear();
            origRow = Console.CursorTop;
            origCol = Console.CursorLeft;
            WriteAt("=======================================", 1, 0);
            WriteAt("|               DEPOSIT               |", 0, 1);
            WriteAt("|=====================================|", 0, 2);
            WriteAt("|          ENTER THE DETAILS          |", 0, 3);
            WriteAt("|                                     |", 0, 4);
            WriteAt("| Account Number:                     |", 0, 5);
            WriteAt("| Amount: $                           |", 0, 6);
            WriteAt("=======================================", 1, 7);
            Console.SetCursorPosition(17, 5);
            String userANinput = Console.ReadLine();
            Console.SetCursorPosition(11, 6);
            String userAMinput = Console.ReadLine();
            Console.SetCursorPosition(0, 9);
            if (File.Exists($"{userANinput}.txt"))
            {
                foreach (bankAccount bk in Accounts)
                {
                    if (bk.accountNumber == Convert.ToInt32(userANinput))
                    {
                        double beforeAM = bk.getBal();
                        bk.Deposit(Convert.ToDouble(userAMinput));
                        double afterAM = bk.getBal();
                        string text = File.ReadAllText($"{userANinput}.txt");
                        text.Replace($"{beforeAM}", $"{afterAM}");
                        
                        File.AppendAllText($"{userANinput}.txt", $"{DateTime.Now.ToString("M/d/yyyy")}|Deposit|{beforeAM}|{afterAM}");

                        Console.WriteLine("Press y to deposit another");
                        String Choice2 = Console.ReadLine();
                        if (Choice2 == "y")
                        {
                            Deposit();
                        }
                        else
                        {
                            Console.WriteLine("Wish to continue another work? (y/n)");
                            String Choice3 = Console.ReadLine();
                            if (Choice3 == "y")
                            {
                                MainPage();
                            }
                            else {
                                Console.WriteLine("Thanks");
                                Console.ReadKey();
                            }
                        }
                    }
                }

            }
            else
            {
                Console.WriteLine("Account not found!");
                Console.WriteLine("Check another account?(y/n)");
                String checkAnother = Console.ReadLine();
                if (checkAnother == "y")
                {
                    Deposit();
                }
                else
                {
                    Console.WriteLine("Thanks");
                    Console.ReadKey();
                }
            }

        }
        public static void Withdraw()
        {
            Console.Clear();
            origRow = Console.CursorTop;
            origCol = Console.CursorLeft;
            WriteAt("=======================================", 1, 0);
            WriteAt("|              WITHDRAW               |", 0, 1);
            WriteAt("|=====================================|", 0, 2);
            WriteAt("|          ENTER THE DEATILS          |", 0, 3);
            WriteAt("|                                     |", 0, 4);
            WriteAt("| Account Number:                     |", 0, 5);
            WriteAt("| Amount: $                           |", 0, 6);
            WriteAt("=======================================", 1, 7);
            Console.SetCursorPosition(17, 5);
            String userANinput = Console.ReadLine();
            Console.SetCursorPosition(11, 6);
            String userAMinput = Console.ReadLine();
            Console.SetCursorPosition(0, 9);
            if (File.Exists($"{userANinput}.txt"))
            {
                foreach (bankAccount bk in Accounts)
                {
                    if (bk.accountNumber == Convert.ToInt32(userANinput))
                    {
                        double beforeAM = bk.getBal();
                        bk.Withdraw(Convert.ToDouble(userAMinput));
                        double afterAM = bk.getBal();
                        string text = File.ReadAllText($"{userANinput}.txt");
                        text.Replace($"{beforeAM}", $"{afterAM}");

                        File.AppendAllText($"{userANinput}.txt", $"{DateTime.Now.ToString("M/d/yyyy")}|Withdraw|{beforeAM}|{afterAM}");

                        Console.WriteLine("Press y to deposit another");
                        String Choice2 = Console.ReadLine();
                        if (Choice2 == "y")
                        {
                            Withdraw();
                        }
                        else
                        {
                            Console.WriteLine("Wish to continue another work? (y/n)");
                            String Choice3 = Console.ReadLine();
                            if (Choice3 == "y")
                            {
                                MainPage();
                            }
                            else
                            {
                                Console.WriteLine("Thanks");
                                Console.ReadKey();
                            }
                        }
                    }
                }
            }
            else
            {
                Console.WriteLine("Account not found!");
                Console.WriteLine("Check another account?(y/n)");
                String checkAnother = Console.ReadLine();
                if (checkAnother == "y")
                {
                    Withdraw();
                }
                else
                {
                    Console.WriteLine("Thanks");
                    Console.ReadKey();
                }

            }
        }
        public static void ACStatement()
        {
            Console.Clear();
            origRow = Console.CursorTop;
            origCol = Console.CursorLeft;
            WriteAt("=======================================", 1, 0);
            WriteAt("|              STATEMENT              |", 0, 1);
            WriteAt("|=====================================|", 0, 2);
            WriteAt("|          ENTER THE DEATILS          |", 0, 3);
            WriteAt("|                                     |", 0, 4);
            WriteAt("| Account Number:                     |", 0, 5);
            WriteAt("=======================================", 1, 6);
            Console.SetCursorPosition(17, 5);
            String userANinput = Console.ReadLine();
            Console.SetCursorPosition(0, 8);

            if (File.Exists($"{userANinput}.txt"))
            {
                foreach (bankAccount bk in Accounts)
                {
                    if (bk.accountNumber == Convert.ToInt32(userANinput))
                    {
                        bk.PrintAccountDetails();
                        Console.WriteLine("Email statement?(y/n)");
                        String userChoice2 = Console.ReadLine();
                        if (userChoice2 == "y")
                        {
                            Console.WriteLine("Processing.....");
                            //email address sending
                            SmtpClient client = new SmtpClient();

                            client.Host = "smtp.gmail.com";
                            client.Port = 587;
                            client.DeliveryMethod = SmtpDeliveryMethod.Network;
                            client.EnableSsl = true;
                            client.UseDefaultCredentials = true;
                            client.Credentials = new NetworkCredential("sehyeon430@gmail.com", "soncyfdxtydfrzhd");
                            client.DeliveryMethod = SmtpDeliveryMethod.Network;
                            MailMessage mail = new MailMessage(new MailAddress("sehyeon430@gmail.com", "simple bank system"), new MailAddress(bk.getEM()));

                            mail.IsBodyHtml = true;
                            mail.Subject = "Bank statement";
                            mail.Body = string.Format($"Dear {bk.getFN()},<br><br>" +
                                        "This is your account detail statement.<br><br>" +
                                        "Your account details are as follow:<br>" +

                                        $"Account number: {bk.getNum()}<br>" +
                                        $"First name: {bk.getFN()}<br>" +
                                        $"Last name: {bk.getLN()}<br>" +
                                        $"Address: {bk.getLN()}<br>" +
                                        $"Phone number: {bk.getPN()}<br>" +
                                        $"Email: {bk.getEM()}<br><br>" +

                                        "Kind regards,<br>" +
                                        "The Simple Banking Team");
                            client.Send(mail);
                            Console.WriteLine("Email successfully sent! Do you want another work? Press y to continue");
                            String chet = Console.ReadLine();
                            if (chet == "y")
                            {
                                ACStatement();
                            }
                            else {

                                Console.WriteLine("Do you want another task? press y to continue");
                                String hy = Console.ReadLine();
                                if (hy == "y")
                                {
                                    MainPage();
                                }

                                else {
                                    Console.WriteLine("Thanks");
                                    Console.ReadKey();
                                }
                            }
                        }
                        else
                        {
                            Console.WriteLine("do you wish to continue another work?(y/n)");
                            String userChoice4 = Console.ReadLine();
                            if (userChoice4 == "y")
                            {
                                MainPage();
                            }
                            else
                            {
                                Console.ReadKey();
                            }
                        }
                    }
                }

            }
            else
             {
                    Console.WriteLine("Account not found!");
                    Console.WriteLine("Check another account?(y/n)");
                    String checkAnother = Console.ReadLine();
                    if (checkAnother == "y")
                    {
                        ACStatement();
                    }
                    else
                    {
                        Console.WriteLine("Thanks");
                        Console.ReadKey();
                    }
             }
        }
        public static void DeleteAccount()
        {
            Console.Clear();
            origRow = Console.CursorTop;
            origCol = Console.CursorLeft;
            WriteAt("=======================================", 1, 0);
            WriteAt("|          DELETE AN ACOOUNT          |", 0, 1);
            WriteAt("|=====================================|", 0, 2);
            WriteAt("|          ENTER THE DEATILS          |", 0, 3);
            WriteAt("|                                     |", 0, 4);
            WriteAt("| Account Number:                     |", 0, 5);
            WriteAt("=======================================", 1, 6);

                Console.SetCursorPosition(17, 5);
                String userANinput = Console.ReadLine();
            Console.SetCursorPosition(0, 8);

            if (File.Exists($"{userANinput}.txt"))
            { 
                foreach (bankAccount bk in Accounts)
                {
                    if (bk.accountNumber == Convert.ToInt32(userANinput))
                    {
                        bk.PrintAccountDetails();
                        
                    }
                }
                Console.WriteLine("Account Found! Do you wish to delete this account?(y/n)");
                String choice1 = Console.ReadLine();
                if (choice1 == "y")
                {
                    File.Delete($"{userANinput}.txt");
                    Console.WriteLine("Account deleted!");
                    Console.WriteLine("Do you widh to delete another account? press y to continue");
                    String userchoice4 = Console.ReadLine();
                    if (userchoice4 == "y")
                    {
                        DeleteAccount();
                    }
                    else
                    {
                        Console.WriteLine("do you wish to continue another work?");
                        String userchoice5 = Console.ReadLine();
                        if (userchoice5 == "y")
                        {
                            MainPage();
                        }
                        else
                        {
                            Console.WriteLine("End of banking system");
                            Console.ReadKey();
                        }
                    }

                }
                else
                {
                    Console.WriteLine("Do you wish to Continue Another work? press y to continue");
                    String choice2 = Console.ReadLine();
                    if (choice2 == "y")
                    {
                        MainPage();
                    }
                    else
                    {
                        Console.WriteLine("End of Simple Bank system");
                        Console.ReadKey();
                    }
                }
            }
            else
            {
                Console.WriteLine("Account not found!");
                Console.WriteLine("Check another account?(y/n)");
                String checkAnother = Console.ReadLine();
                if (checkAnother == "y")
                {
                    DeleteAccount();
                }
                else
                {
                    Console.WriteLine("Do you wish to Continue Another work? (y/n)");
                    String choice3 = Console.ReadLine();
                    if (choice3 == "y")
                    {
                        MainPage();
                    }
                    else
                    {
                        Console.WriteLine("End of Simple Bank system");
                        Console.ReadKey();
                    }

                }
            }
           
        }
        
    }
}
