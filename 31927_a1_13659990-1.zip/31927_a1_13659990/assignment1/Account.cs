﻿using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Collections.Generic;
using System.Transactions;

namespace assignment1
{
    public class bankAccount
    {
        public readonly int accountNumber;
        private double balance;
        private string firstName, lastName, address, phoneNumber, email;
        

        public bankAccount(int accountNumber, double balance, string firstName, string lastName,
                           string address, string phoneNumber, string email)
        {
            this.accountNumber = accountNumber;
            this.balance = balance;
            this.firstName = firstName;
            this.lastName = lastName;
            this.address = address;
            this.phoneNumber = phoneNumber;
            this.email = email;
        }

        
        public void PrintAccountDetails()
        {
            Console.WriteLine(" _____________________________________________________________");
            Console.WriteLine(" |                                                           |");
            Console.WriteLine(" |                      ACCOUNT DETAILS                      |");
            Console.WriteLine(" |___________________________________________________________|");
            Console.WriteLine(" |                                                           |");
            Console.WriteLine($" |    Account Number: {accountNumber}".PadRight(61, ' ') + "|");
            Console.WriteLine($" |    Account Balance: ${balance:0.00}".PadRight(61, ' ') + "|");
            Console.WriteLine($" |    First Name: {firstName}".PadRight(61, ' ') + "|");
            Console.WriteLine($" |    Last Name: {lastName}".PadRight(61, ' ') + "|");
            Console.WriteLine($" |    Address: {address}".PadRight(61, ' ') + "|");
            Console.WriteLine($" |    Phone: {phoneNumber}".PadRight(61, ' ') + "|");
            Console.WriteLine($" |    Email: {email}".PadRight(61, ' ') + "|");
            Console.WriteLine(" |___________________________________________________________|");
            Console.WriteLine();
        }
        public bool HasNumber(int accountNumber)
        {
            return this.accountNumber == accountNumber;
        }

        public void Withdraw(double amount)
        {
            if (balance >= amount)
            {
                balance -= amount;
                
            }
        }
        public void Deposit(double amount)
        {
            balance += amount;
            
        }
        public int getNum()
        {
            return accountNumber;
        }
        public double getBal()
        { 
            return balance;
        }
        public String getFN()
        { 
            return firstName;
        }

        public String getLN()
        {
            return lastName;
        }
        public String getAD()
        {
            return address;
        }

        public String getPN()
        {
            return phoneNumber;
        }
        public String getEM()
        {
            return email;
        }

    }
}
