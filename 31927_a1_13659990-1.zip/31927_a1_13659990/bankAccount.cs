﻿using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Collections.Generic;

namespace assignment1
{
    public class bankAccount
    {
        private readonly int accountNumber;
        private double balance;
        private string firstName, lastName, address, phoneNumber, email;

        public BankAccount(int accountNumber, double balance, string firstName, string lastName,
                           string address, string phoneNumber, string email)
        {
            this.accountNumber = accountNumber;
            this.balance = balance;
            this.firstName = firstName;
            this.lastName = lastName;
            this.address = address;
            this.phoneNumber = phoneNumber;
            this.email = email;
        }

        
    }

}